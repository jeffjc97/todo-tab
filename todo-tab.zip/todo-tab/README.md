# SimpleNotes

Find on Chrome Web Store:
https://chrome.google.com/webstore/detail/simple-notes/ldfahoabcdgljodjddijjiknleolbcmh?hl=en-US&gl=US

A simple notes extension based off the Mac Notes app.
With simple notes, you can take and save notes. It's that simple.

Other note taking apps have features of mostly little use, ones that can get in the way of usability and convenience. I have always enjoyed the simplicity of the Apple Notes app, both in design and usability, so I decided to base this extension on that app. Hope you enjoy! 

Note: This extension does not sync with your Apple notes.

See Screenshots and Functionality here: http://imgur.com/a/c9i1E
